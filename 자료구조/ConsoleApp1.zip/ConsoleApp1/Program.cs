﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Monster
    {
        public int id;

        public Monster(int id) { this.id = id; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();

            Dictionary<int, Monster> dic = new Dictionary<int, Monster>();
            for (int i = 0; i < 10000; i++)
            {
                dic.Add(i, new Monster(i));
            }
            // 해당하는 값이 없으면 crash
            //Monster mon = dic[5000];
            
            // 별도 함수 - 성공유무 boolean 타입 값 반환
            Monster mon;
            dic.TryGetValue(20000, out mon);

            dic.Remove(7777); // 해당하는 인덱스의 값 삭제
        }
    }
}
